--entity
require("prototypes.vls-turret")

--items
--require("prototypes.turret-ammo")

--tech
require("prototypes.technology-vls-turret")